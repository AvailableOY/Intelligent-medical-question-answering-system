from django.http import JsonResponse,StreamingHttpResponse
from django.conf import settings
print(settings.VLLM_CONFIG)
from .Qwen import Deepseek
qwen = Deepseek(host=settings.VLLM_CONFIG.get("host"),
                model=settings.VLLM_CONFIG.get("model"))
def ai_chat_123(request):
    question = request.POST.get("question"," ")
    messages = [
        {"role": "system", "content": "你是一个AI助手"},
        {"role": "user", "content": question}
    ]
    data = qwen.inference(messages,True)
    # data = {
    #     "code" : 200,
    #     "message" : "刮风这天 我试过握着你手~"
    # }
    # 创建流式响应
    response = StreamingHttpResponse(data, content_type="text/event-stream")
    #直接响应到客户端，禁止缓存
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"]= "no" # 禁止: Nginx 缓冲
    return {"code":200, "message":response}

    return JsonResponse(data,safe=False)

def chatlist(request):
    chatlist = [
        {
            "id" : 1,
            "name" : "周杰伦"
        },
        {
            "id" : 2,
            "name" : "王力宏"
        }
    ]
    return JsonResponse(chatlist,safe=False)
